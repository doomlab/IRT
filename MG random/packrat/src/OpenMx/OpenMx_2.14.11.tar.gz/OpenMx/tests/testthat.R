library(testthat)
library(OpenMx)

test_check("OpenMx")
