#ifndef _ALGEBRAOP_H_
#define _ALGEBRAOP_H_

class omxMatrix;
typedef void (*algebra_op_t)(FitContext *fc, class omxMatrix**, int, class omxMatrix*);

#endif
