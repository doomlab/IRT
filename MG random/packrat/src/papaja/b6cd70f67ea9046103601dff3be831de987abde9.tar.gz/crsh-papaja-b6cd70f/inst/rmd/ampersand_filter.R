papaja:::ampersand_filter()
