Paul Johnson
20171005


mydf.templ.csv: generated from keyTemplate
mydf.key.csv: manual revision of mydf.templ.csv

mydf.key_long.csv: a long version of a key that is supposed to be
equivalent to mydf.key.csv.  Because of mis-matches, we use
wide2long() to generate this file.

mydf.key_long2.csv: a manually edited version of mydf.key_long.csv
that has additional variables.
